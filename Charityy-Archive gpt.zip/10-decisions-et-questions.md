# 10 — Décisions et questions ouvertes

## Décisions issues du brief

| Sujet | Décision de travail | État |
|---|---|---|
| Cible | mondiale | lancement limité aux territoires conformes |
| Localisation | détection pays et langue/devise automatiques | suggestion modifiable; conversion explicite |
| Paiements | Moneroo uniquement au départ | vérifier fonctions, contrats et corridors |
| Fonds | appartiennent au bénéficiaire; Charityy ne les gère pas directement | confirmer flux marchand/règlement réel |
| Collecte | pièce d’identité valide demandée; revue humaine | définir exigences par pays et alternatives |
| Signatures | seuil proposé de 100, avec groupes de signataires | anti-abus, accessibilité et règle finale à valider |
| Vérification ressource | documents, téléphone, email institutionnel | procédure de preuve et sources indépendantes |
| Certification | taux évoqué de 5 % | base et légalité non définies; bloqué avant facturation |
| Revenus créateur | 2 % sur cagnotte, live, cadeaux, produits et campagne commerciale | assiette et financement à définir |
| Wallet | chargement, dépenses et paiement direct Moneroo si solde nul | ne pas activer avant analyse réglementaire |
| Équipe | droits attribuables à des comptes équipe | RBAC, MFA, journal, double contrôle |
| Livraison | réalisation en plusieurs étapes jusqu’à app complète | feuille de route document 07 |
| Marque | logo/domaine/réglages en fin de projet | noms et textes légaux tout de même requis avant sortie |

## Décisions nécessaires au lancement

1. Pays pilote(s) et entité juridique opératrice.
2. Qui est marchand contractuel et qui reçoit les fonds techniquement? Moneroo offre-t-il le reversement direct ou split settlement requis?
3. Devises réellement acceptées, devise de règlement, source/taux de conversion et moment où le taux devient ferme.
4. Frais exacts, assiettes et ordre de répartition entre fournisseur, bénéficiaire, Charityy et créateur.
5. Nature juridique du wallet et des unités cadeau; possibilité de remboursement/transferabilité; exigences licence.
6. Certification : service gratuit ou tarif fixe/%? Comment éviter que la capacité de payer influence le statut de confiance?
7. Répartition des 100 signatures et méthode de vérification sans exclure les communautés isolées.
8. Règles pour mineurs, urgences médicales, décès du bénéficiaire, fausses pièces et bénéficiaires tiers.
9. Langues initiales, traduction automatique ou traductions révisées pour CGU/support.
10. Engagements support/modération, horaires, délais par gravité et contact de crise.
11. Région hébergement, conservation des preuves, sous-traitants et gestion des demandes d’autorités.
12. Nom de domaine, marque, conditions d’usage, confidentialité, cookies et politique de remboursement.

## Décisions recommandées par défaut

- Commencer dans un nombre restreint de pays compatibles avec Moneroo et un conseil local.
- PWA d’abord, paiements directs transactionnels ensuite, pas de solde préchargé dans le MVP.
- Garder les signatures comme facteur de communauté, sans en faire certification.
- Ne pas prélever le pourcentage de certification jusqu’à définition et revue juridique; proposer une procédure d’examen sans frais pour l’accès aux aides essentielles.
- Définir des statuts précis et ne jamais amalgamer identité vérifiée, campagne examinée, signature et preuve de paiement.
