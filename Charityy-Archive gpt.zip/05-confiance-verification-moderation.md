# 05 — Confiance, vérification et modération

## 1. Niveaux de statut affichés

- Identité/contact vérifié : méthode et date, sans divulguer le document.
- Campagne examinée : l’équipe a vérifié des éléments définis et listés.
- Ressource confirmée : qualité et relation vérifiées via méthodes documentées.
- Communauté mobilisée : nombre de signatures valides selon règles.
- Fonds confirmés/réglés : statut technique distinct fourni par le rapprochement.

Éviter les termes absolus tels que « garantie », « 100 % vraie » ou « fonds sécurisés » si l’équipe ne peut l’établir.

## 2. Demande de campagne

Pour toute demande : preuve d’identité valide via flux privé, contact vérifié, identité du bénéficiaire réel, relation du demandeur, objectif et échéance, justificatifs proportionnés, consentement et autorisation des personnes représentées. Pour mineurs, demandes médicales et urgences, définir protocole de représentation et escalade spécialisé.

Les documents doivent être accessibles uniquement au personnel explicitement autorisé, avec journal d’accès, stockage privé, URL éphémère, chiffrement, politique de conservation/suppression et procédure de demande d’effacement lorsque légalement possible.

## 3. Vérification humaine

1. Triage par risque et complétude.
2. Vérifier cohérence identité/bénéficiaire/coordonnées et pièces.
3. Contrôler documents via organisme émetteur ou canal indépendant lorsque pertinent.
4. Pour personnes ressources, vérifier qualité par document officiel, téléphone ou adresse institutionnelle obtenue indépendamment; une adresse auto-déclarée ne suffit pas.
5. Documenter contrôles, sources, date, reviewer et résultat sans recopier plus de données que nécessaire.
6. Résultat : approuvé, complément requis, rejet motivé, escalade fraude/sécurité.
7. Contrôle de second niveau pour montants/risques définis; voie d’appel et réexamen.

## 4. Règle des 100 signatures

Le seuil et les proportions source (40 % proches, 30 % ressources, 30 % communauté) sont une règle produit proposée, à valider par étude d’abus et d’accessibilité. Le système doit expliquer que les signatures n’attestent pas les faits ni la solvabilité. Définir identité minimale, unicité, retrait, abus coordonné, conflits d’intérêt et traitement des personnes sans réseau. Ne jamais empêcher une alerte urgente ou une demande d’aide non financière en attendant le seuil.

## 5. Modération

Catégories : fraude, usurpation, exploitation, harcèlement, données privées, violence, contenu médical sensible, sexualisation de mineurs, discours haineux, spam, incitation dangereuse. Mesures graduées : avertissement, retrait, limitation, suspension, gel de campagne selon autorité légale/contrat et procédure d’appel. Prévoir signalement accessible, accusé de réception, délais cibles par gravité, équipes de crise, protection du personnel exposé et conservation probatoire limitée.

## 6. Aide et urgences

Le produit ne remplace pas services d’urgence. Ne pas afficher de géolocalisation précise par défaut. Pour les contenus impliquant danger immédiat, afficher des ressources locales seulement si validées et à jour. Définir les règles de divulgation aux autorités en consultation juridique.

## 7. Transparence

Publier règles de certification, limites, critères de suspension, frais, nombre de campagnes examinées/refusées, plaintes et délais agrégés sans exposer les demandeurs. Permettre mises à jour des campagnes et signalement d’usage non conforme.
