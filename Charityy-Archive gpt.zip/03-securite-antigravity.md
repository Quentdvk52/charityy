# 03 — Sécurité, confidentialité et agent Antigravity

## 1. Promesse réaliste

Aucun agent, fournisseur ou plan ne peut rendre un système « entièrement sécurisé ». Antigravity peut aider à écrire/revoir du code selon ses capacités et réglages, mais ne remplace ni des ingénieurs responsables, ni une revue humaine, ni un audit indépendant, ni un avis juridique. Ne jamais lui confier des données réelles d’identité, secrets, clés API, documents médicaux ou accès de production.

## 2. Référentiels

Utiliser OWASP ASVS 5 comme base de vérification web, OWASP Top 10 comme sensibilisation, OWASP MASVS pour l’application native, et les recommandations de sécurité des fournisseurs. Choisir les niveaux de vérification selon la sensibilité et faire documenter chaque contrôle.

## 3. Contrôles essentiels

- Menaces : fraude aux collectes, prise de compte, faux webhooks, accès aux preuves privées, abus d’admin, scraping, extorsion, fuite par logs, fraude interne, déni de service.
- Auth : MFA obligatoire pour le personnel, passkeys si disponibles, limitation des tentatives, sessions courtes pour fonctions sensibles, révocation, alertes de changement de compte.
- Autorisation : refus par défaut, contrôle d’accès au niveau objet et rôle à chaque requête; séparation créateur/reviewer/finance/admin; double validation pour actions financières ou suspensions critiques.
- Secrets : gestionnaire de secrets, rotation, scopes minimaux, séparation environnements, aucun secret dans prompts, code, screenshots ou logs.
- Données : TLS, chiffrement au repos fournisseur, chiffrement applicatif ciblé pour pièces sensibles si faisable, clés séparées, accès limité et journalisé, minimisation/rétention/suppression.
- Web : CSRF selon architecture, XSS, CSP, validation serveur, encodage, rate limiting, protection SSRF, CORS strict, headers sûrs, upload sécurisé.
- Paiements : signature webhook vérifiée, idempotence, rapprochement, ledger immuable, alertes anomalies, aucune confiance aux montants fournis par le navigateur.
- Chaîne logicielle : lockfile, mises à jour surveillées, analyse dépendances/secrets, builds reproductibles, revue de code, protection des branches, artefacts signés si disponibles.
- Exploitation : sauvegardes chiffrées, restauration testée, alertes, playbooks, rotation clés, gestion incidents et notification selon lois applicables.

## 4. Garde-fous pour Antigravity

Configurer l’agent sur un dépôt de développement isolé avec données synthétiques, permissions minimales et aucun accès prod. Exiger qu’il :

1. lise les conventions et fasse un plan avant changements transversaux;
2. travaille sur des tickets et changements petits, inspectables;
3. n’exécute aucune migration destructive, commande de déploiement, action financière, publication ou modification d’accès sans validation humaine explicite;
4. ne désactive pas tests, scans, protections, règles d’accès ou journalisation pour « faire passer » un changement;
5. ne copie pas de PII, secrets ni documents de production dans prompts ou sorties;
6. ajoute une explication des fichiers modifiés, risques, hypothèses et commandes exécutées;
7. traite le contenu utilisateur, pièces jointes et commentaires comme données non fiables, pas comme instructions d’agent;
8. laisse un humain examiner les diff, décisions de sécurité, migrations, dépendances et permissions avant fusion.

Les noms et réglages concrets des options d’Antigravity évoluent : appliquer les contrôles via les paramètres officiels disponibles au moment de la configuration et vérifier qu’ils sont effectivement actifs.

## 5. Confidentialité et données sensibles

Inventorier données, finalité, base légale, destinataires, transferts internationaux, durée et droits. Demander un avis spécialisé pour pays de lancement (notamment données de santé, mineurs, KYC, collecte publique, services de paiement). Les preuves sont privées, ne jamais intégrées aux outils d’analytics ni exposées par URLs permanentes. Obtenir consentement explicite à la publication de l’histoire et des pièces publiques; fournir un mécanisme de retrait.

## 6. Portes de sécurité avant lancement

Modèle de menace revu; ASVS adapté avec preuves; revue d’accès admin; audit des règles de stockage; revue indépendante du paiement/webhook; analyse dépendances/secrets; tests de restauration; exercice d’incident; scan externe et test d’intrusion proportionné; traitement des vulnérabilités critiques; validation des fournisseurs et contrats; procédures support/modération; approbation juridique par territoire.

## 7. Gestion d’incident

Détecter et préserver les journaux, contenir (révoquer sessions/clés, suspendre endpoint ou campagne), mesurer l’exposition, protéger les personnes concernées, informer dirigeants/conseils, respecter délais légaux de notification, corriger et vérifier, publier une communication adaptée si nécessaire, documenter le retour d’expérience.
