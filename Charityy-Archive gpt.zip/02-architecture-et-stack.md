# 02 — Architecture et stack technique

## 1. Principes

Construire un monolithe modulaire avec frontières métier nettes pour le MVP. Éviter microservices prématurés. Toutes les opérations financières et permissions sont vérifiées au serveur. Les médias vidéo, documents KYC et documents publics utilisent des espaces/buckets et politiques distincts.

## 2. Stack proposée

| Domaine | Choix de départ | Motif / réserve |
|---|---|---|
| Web | Next.js App Router, React, TypeScript | UI et API web dans un dépôt; revoir version stable au démarrage |
| UI | Tailwind CSS + composants accessibles Radix/shadcn | composants contrôlés et accessibles |
| Formulaires | React Hook Form + Zod | validation partagée, toujours revalider au serveur |
| Données client | TanStack Query; Zustand uniquement pour état local | cache serveur distinct de l’état UI |
| Backend | Route Handlers puis modules de domaine | logique métier testable hors composants |
| Base | PostgreSQL managé (Neon ou fournisseur comparable) | transactions, contraintes et migrations; vérifier région, sauvegardes et contrat |
| ORM | Prisma | migrations examinées et contraintes DB complétées par SQL si nécessaire |
| Auth | Auth.js ou fournisseur spécialisé choisi après analyse | MFA, sessions, récupération et journaux; pas de choix final sans prototype de flux |
| Stockage | Cloudflare R2 ou stockage compatible S3 | URLs signées courtes, chiffrement, séparation KYC/public |
| Vidéo | Cloudflare Stream ou Mux | transcodage, diffusion adaptative; comparer coût, régions, modération et suppression |
| Paiements | Moneroo | intégration serveur, webhooks signés, idempotence; confirmer produits disponibles |
| Email | Resend/Postmark | messages transactionnels sans données sensibles inutiles |
| Jobs | QStash/Redis managé | tâches asynchrones et reprises idempotentes |
| Erreurs | Sentry + logs structurés minimisés | filtrer PII/secrets avant envoi |
| Analytics | PostHog en configuration respectueuse de la vie privée | consentement, rétention courte et désactivation des captures sensibles |
| Déploiement | plateforme compatible Next.js + région appropriée | Vercel possible, mais évaluer résidence, coûts et secrets |
| Mobile futur | Expo + React Native | partager modèles et API; sécuriser stockage local |
| Tests (phase équipe) | Vitest, Playwright | tests unitaires/intégration/E2E avant mise en production |

## 3. Domaines du code

`identity`, `profiles`, `media`, `campaigns`, `verification`, `signatures`, `payments`, `ledger`, `moderation`, `notifications`, `admin`, `audit`. Chaque module expose des fonctions serveur; seuls les modules de paiement/ledger peuvent créer des écritures financières. UI ne calcule jamais un solde autoritatif.

## 4. Modèle de données à concevoir

Principales entités : User, Role, Permission, Session, Campaign, CampaignEvidence (privée), Review, Signature, DonationIntent, ProviderPayment, LedgerEntry, Payout/Settlement (selon capacités Moneroo), Refund, Report, ModerationAction, Consent, AuditEvent, CurrencyRate. Les enregistrements monétaires sont des entiers en unités mineures, avec code ISO de devise; jamais de float. Toute écriture financière immuable et équilibrée (double entrée) ou représentation équivalente auditée.

## 5. Flux médias

Le client demande une URL d’upload éphémère au backend. Le serveur vérifie session, taille/type, quota et statut de compte. Le média arrive en quarantaine; analyse antivirus et validation réelle du type; transcodage et modération; publication uniquement après résultat acceptable. Les preuves KYC ne sont jamais servies via CDN public. URLs de lecture temporaires, accès audité, suppression selon politique de conservation.

## 6. Flux paiement

Le backend crée l’intention auprès du fournisseur avec montant/devise/campagne et clé idempotente. L’utilisateur est redirigé/présenté au checkout officiel. La confirmation navigateur ne vaut pas règlement. Le webhook est authentifié, dédupliqué, rapproché du montant/devise/référence, puis écrit dans le ledger. États inconnus/contradictoires vont en revue manuelle; les jobs de rapprochement comparent périodiquement l’API fournisseur et le ledger.

## 7. Localisation et devises

Locale issue du navigateur/pays estimé n’est qu’une valeur initiale. Stocker préférence explicite. Les prix en monnaies étrangères sont des conversions indicatives avec taux, source et horodatage; le checkout précise le montant final et les frais. Ne pas convertir rétroactivement la devise de la campagne.

## 8. Décisions d’hébergement à prendre

Comparer résidence et transferts de données, chiffrement, sous-traitants, sauvegardes et restauration, SLA, coût de stockage/egress vidéo, observabilité, limites d’exécution serverless, protection DDoS et procédure de sortie fournisseur. Établir un environnement dev/staging/prod isolé et des comptes de service minimaux.
