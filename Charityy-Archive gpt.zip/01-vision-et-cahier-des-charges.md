# 01 — Vision et cahier des charges

## 1. Vision

Charityy est un réseau social vidéo qui aide les personnes, associations et entreprises à mobiliser des communautés autour de causes sociales, sanitaires, éducatives, humanitaires et entrepreneuriales. Le produit relie une histoire, des preuves, une communauté, des actions de soutien et, quand les conditions sont réunies, une collecte.

La plateforme doit rendre visible la différence entre contenu publié, campagne soumise, campagne examinée par l’équipe, campagne certifiée et fonds effectivement réglés au bénéficiaire. Un badge ne doit jamais laisser entendre une garantie de résultat ou d’utilisation future.

## 2. Public et périmètre

- Grand public, porteurs de projets, bénéficiaires, créateurs, associations/ONG, donateurs, personnes ressources, équipe Charityy.
- Vision mondiale. Le lancement opérationnel doit être limité aux pays et corridors de paiement effectivement supportés et conformes.
- Web mobile-first avec PWA au démarrage; applications natives ensuite si les usages le justifient.
- Langues et monnaies localisées. Le pays est une suggestion déterminée par signaux disponibles; l’utilisateur peut la corriger. Ne pas inférer ou publier une position précise sans consentement.

## 3. Rôles

- Visiteur : consulter le contenu public et les campagnes publiées.
- Membre : profil, publication, suivi, commentaires, signatures et dons.
- Créateur/bénéficiaire : campagnes et justificatifs, après vérifications requises.
- Organisation : profil organisationnel et pièces institutionnelles.
- Personne ressource : attester un lien ou soutenir, après vérification de son identité et de sa qualité déclarée.
- Équipe : rôles séparés de vérification, modération, support, finance et administration.
- Administrateur sécurité : gérer accès et incidents; pas d’accès automatique au contenu privé des justificatifs.

## 4. Fonctionnalités produit

### Comptes et profils

Inscription par téléphone ou e-mail; authentification multifacteur recommandée pour les comptes sensibles et obligatoire pour l’équipe. Profils publics minimisés, confidentialité, blocage, export et suppression de compte sous réserve des obligations de conservation légale.

### Publications vidéo

Flux vertical, upload vidéo, légende, catégories, hashtags, langue, localisation facultative au niveau ville/pays, sous-titres, réactions, commentaires, partage, signalement et visibilité paramétrable. Les documents sensibles ne doivent pas être inclus dans les médias publics par défaut.

### Campagnes

Formulaire guidé : bénéficiaire, cause, objectif, devise, échéance, bénéficiaire du règlement, explication, justificatifs privés, consentements, coordonnées vérifiées et plan de mise à jour. État machine contrôlé (brouillon, soumise, informations requises, en examen, approuvée, publiée, suspendue, clôturée, remboursement en cours, terminée). Toute transition importante est auditée.

### Signatures

Une personne vérifiée peut soutenir une campagne selon des règles anti-abus, avec consentement et déduplication. Les catégories proches/personnes ressources/communauté peuvent être proposées, mais déclarées et modérées; les signatures ne valent ni expertise ni preuve financière. Ne pas publier les noms sans consentement explicite.

### Lives et cadeaux

Reporter après le MVP. Live avec outils de modération, délai de diffusion si possible, signalement, blocage, arrêt d’urgence et politique de rediffusion. Les cadeaux et unités virtuelles nécessitent registre de valeur, règles de remboursement, prévention d’abus et validation légale et fournisseur.

## 5. Parcours critique d’une collecte

1. Le demandeur crée un brouillon et vérifie son contact.
2. Il fournit les informations et documents requis via un espace privé sécurisé.
3. Les contrôles automatisés détectent les champs manquants et doublons sans décider seuls du refus.
4. Un agent habilité vérifie la demande, documente les contrôles et peut demander des compléments.
5. La campagne est approuvée et publiée avec statut et limites visibles.
6. Les signatures et dons sont journalisés; les événements prestataire sont vérifiés côté serveur.
7. Le bénéficiaire fournit les mises à jour convenues; les retraits/règlements suivent le flux confirmé avec Moneroo.
8. À clôture, afficher les montants collectés, frais connus, montant réglé si confirmé, statut et incidents/réclamations pertinents.

## 6. Exigences non fonctionnelles

- Mobile-first, faible consommation de données, reprise d’upload et interfaces accessibles (WCAG 2.2 AA comme cible).
- Disponibilité, latence et volumes à établir avec objectifs mesurables avant bêta.
- Journal d’audit append-only pour opérations sensibles; sauvegardes chiffrées et exercices de restauration.
- Aucun secret dans le navigateur, dépôt Git ou journaux.
- Observabilité avec minimisation des données personnelles.
- Modération et support adaptés aux langues et fuseaux horaires du lancement.

## 7. Hors lancement

Recommandation algorithmique opaque, versements automatisés sans contrôles, place de marché d’investissement, wallet retirable sans cadre juridique, IA prenant seule des décisions de fraude ou de certification, diffusion mondiale instantanée de paiements.
