# 06 — Design, UX et animations 2D/3D

## 1. Direction visuelle

Interface mobile-first, humaine, claire, professionnelle. Palette neutre et accents réservés aux actions, urgence et statut de vérification. Conserver une hiérarchie simple : histoire, bénéficiaire, objectif, montant effectivement reçu, preuves disponibles et prochaine action. Respecter contraste, navigation clavier, lecteurs d’écran, sous-titres et réduction des mouvements.

## 2. Bibliothèques

- Framer Motion (motion/react) : transitions UI, gestes et micro-interactions 2D.
- Three.js : moteur 3D général si une scène apporte une vraie valeur.
- React Three Fiber + Drei : intégration Three.js dans React et utilitaires.
- Lottie via lottie-react : animations vectorielles légères, contrôlées.
- CSS transforms/animations natives : premier choix pour interactions simples.

N’utiliser qu’une scène 3D à la fois, chargée à la demande. Éviter la 3D décorative dans le flux vidéo, l’écran don et les formulaires de vérification. Ne jamais laisser animation retarder l’accès au don ou masquer l’état de sécurité.

## 3. Usages appropriés

- Progression de campagne : barre 2D accessible, valeur textuelle toujours disponible.
- Confirmation d’action : micro-animation courte, désactivée si `prefers-reduced-motion`.
- Découverte/illustration de mission : scène 3D facultative et non bloquante dans l’accueil marketing, jamais comme seule source d’information.
- Indicateurs d’impact : graphiques 2D plus lisibles et sobres.

## 4. Budget de performance

Tester appareil bas de gamme et réseau lent. Limiter poids initial, polygones, textures, appels de rendu et dépendances; charger en différé, réduire résolution sur mobile, suspendre rendu hors écran, fournir image/poster statique et fallback sans WebGL. Respecter `prefers-reduced-motion`, économie de données et absence de WebGL. Pas d’animation clignotante.

## 5. Composants UX prioritaires

Fil vidéo avec contrôles accessibles; création campagne en étapes avec sauvegarde brouillon; carte de campagne indiquant devise et date; progression; justificatifs explicitement publics/privés; formulaire de don récapitulant montant, frais et bénéficiaire; historique lisible; états d’erreur avec reprise sûre.

## 6. Identité de marque

Logo, domaine et identité seront définis en fin de cadrage de marque, mais les noms de produit, textes légaux, couleurs de statut et exigences d’accessibilité doivent être cohérents dès le prototype. Ne pas imiter TikTok ou réutiliser des assets non licenciés.
