# Charityy — index du dossier projet

Version de travail : 1.0 — 11 novembre 2026

Ce dossier transforme l’idée et les décisions fournies en base de travail pour une équipe produit, technique, sécurité et opérations. Il ne garantit pas une réussite « à 100 % » ni une sécurité absolue : ces résultats dépendent de l’exécution, des prestataires, des audits et des lois applicables. La sécurité est conçue en profondeur, vérifiée en continu et accompagnée d’une réponse aux incidents.

## Documents

1. [Vision et cahier des charges](01-vision-et-cahier-des-charges.md)
2. [Architecture et stack technique](02-architecture-et-stack.md)
3. [Sécurité, confidentialité et rôle de l’agent Antigravity](03-securite-antigravity.md)
4. [Paiements, portefeuille et règles financières](04-paiements-et-finances.md)
5. [Confiance, vérification et modération](05-confiance-verification-moderation.md)
6. [UX, design et animations 2D/3D](06-design-animations.md)
7. [Plan de réalisation et critères d’acceptation](07-feuille-de-route.md)
8. [Opérations, administration et gouvernance](08-operations-gouvernance.md)
9. [Liens officiels d’installation et de référence](09-liens-et-installation.md)
10. [Registre des décisions et questions ouvertes](10-decisions-et-questions.md)

## Décisions structurantes consignées

- Cible mondiale, interface localisée selon les préférences et signaux de pays, avec langue/devise confirmables par l’utilisateur.
- Montants canoniques enregistrés dans une devise de base par campagne; conversion affichée avec taux et date. Aucun montant ne change silencieusement au paiement.
- Moneroo est l’agrégateur de paiement prévu; la plateforme ne prétend pas conserver ou séquestrer les fonds. Le flux réel de règlement, les frais, les remboursements et les reversements doivent être confirmés avec Moneroo et les conseils juridiques/financiers.
- Identité obligatoire pour demander une collecte; 100 signatures sont un signal communautaire, jamais une preuve d’identité ni une certification.
- Vérification et modération humaines avec permissions d’administration attribuables par rôle.
- Le taux de 5 % lié à la certification et la rémunération de créateur de 2 % ne sont pas cumulés ou prélevés avant validation juridique, commerciale et d’interface.
- Lancement par application web mobile-first/PWA; application native, live et cadeaux évoluent par étapes.

## Utilisation

Lire les documents dans l’ordre. Les mentions « à valider » sont des décisions bloquantes avant activation publique ou traitement réel de fonds. Les liens sont des références vers les documentations officielles connues à la date de rédaction; vérifier les versions et les conditions des fournisseurs avant implémentation.
