# 07 — Feuille de route et critères d’acceptation

## Phase 0 — Décisions et fondations

Choisir territoires de bêta, vérifier Moneroo, modèle de fonds, statut juridique, politiques de données, menace, fournisseurs et marque minimale. Livrable : décisions signées, environnements isolés, modèle de données, backlog priorisé, maquettes des parcours sensibles.

**Sortie :** aucun parcours de fonds codé sur hypothèses non confirmées; responsables produit, sécurité, conformité et opérations identifiés.

## Phase 1 — MVP web/PWA sans fonctions financières non clarifiées

Comptes, profils, flux vidéo, upload sécurisé, commentaires/réactions, signalements, campagne brouillon/soumise, pièces privées, vérification manuelle, console d’équipe avec RBAC, statuts, signatures et localisation approximative, notification transactionnelle.

**Acceptation :** permissions négatives vérifiées; documents privés inaccessibles publiquement; chaque action d’équipe auditée; consentements sauvegardés; suppression/export traités; design accessible et fonctionnel en réseau lent.

## Phase 2 — Bêta paiement limitée

Intégration Moneroo sandbox puis production restreinte; checkout direct, webhook et ledger; rapprochement; reçus; remboursements selon capacités confirmées; reporting financier; lancement sur corridors autorisés.

**Acceptation :** tests de webhook invalide/rejoué, montant modifié, événement retardé et état contradictoire; pas de double crédit; flux rapproché avec fournisseur; contrats et politiques visibles.

## Phase 3 — Confiance et croissance

Certification si modèle validé, recherche, notifications avancées, tableau créateur, analytics agrégées, langues supplémentaires, gestion de litiges et outils de support.

## Phase 4 — Live, cadeaux, wallet, mobile natif

Étude fournisseur et légale séparée; modération live; économie des cadeaux; wallet uniquement après autorisation juridique et contrôles de ledger; Expo/React Native et durcissement mobile.

## Critères de lancement public

- Territoires et langues couverts définis.
- Avis juridique/comptable et contrats paiements signés.
- SLO, support, modération et astreinte fixés.
- Évaluation sécurité indépendante et correctifs critiques/élevés traités.
- Restauration de sauvegarde et réponse incident exercées.
- Parcours KYC, consentement, suppression et plainte testés.
- Prestataires, transferts, rétention et accès documentés.
- Plan de rollback et communication prêt.

## Découpage des tickets

Chaque ticket précise rôle, scénario, états, permissions, événements audit, données, critères d’acceptation, accessibilité, erreurs, dépendances et risques. Une fonctionnalité financière ou identité ne peut être « terminée » sur la seule base d’une interface démontrable.
