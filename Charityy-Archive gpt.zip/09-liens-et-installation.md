# 09 — Liens officiels d’installation et de référence

Liens consultés le 11 novembre 2026. Les versions évoluent : privilégier la documentation officielle et épingler les versions compatibles au moment du démarrage.

## Environnement

- Node.js : https://nodejs.org/en/download
- Git : https://git-scm.com/downloads
- VS Code : https://code.visualstudio.com/download
- GitHub CLI : https://cli.github.com/

## Frontend et interface

- Next.js installation : https://nextjs.org/docs/app/getting-started/installation
- React : https://react.dev/learn
- TypeScript : https://www.typescriptlang.org/download/
- Tailwind CSS : https://tailwindcss.com/docs/installation
- shadcn/ui : https://ui.shadcn.com/docs/installation/next
- Radix UI : https://www.radix-ui.com/primitives/docs/overview/introduction
- React Hook Form : https://react-hook-form.com/get-started
- Zod : https://zod.dev/
- TanStack Query : https://tanstack.com/query/latest/docs/framework/react/installation
- PWA / Web App Manifest : https://developer.mozilla.org/docs/Web/Progressive_web_apps

## Animation et 3D

- Motion for React (anciennement Framer Motion) : https://motion.dev/docs/react
- Three.js : https://threejs.org/manual/#en/installation
- React Three Fiber : https://r3f.docs.pmnd.rs/getting-started/introduction
- Drei : https://github.com/pmndrs/drei
- Lottie React : https://github.com/Gamote/lottie-react
- prefers-reduced-motion : https://developer.mozilla.org/docs/Web/CSS/@media/prefers-reduced-motion

## Backend et données

- PostgreSQL : https://www.postgresql.org/download/
- Neon : https://neon.tech/docs/introduction
- Prisma : https://www.prisma.io/docs/getting-started
- Auth.js : https://authjs.dev/getting-started
- Cloudflare R2 : https://developers.cloudflare.com/r2/get-started/
- Cloudflare Stream : https://developers.cloudflare.com/stream/get-started/
- Mux : https://docs.mux.com/guides
- Upstash QStash : https://upstash.com/docs/qstash/overall/getstarted
- Redis : https://redis.io/docs/latest/get-started/

## Paiement, messagerie, supervision

- Moneroo API docs : https://docs.moneroo.io/
- Moneroo authentication : https://docs.moneroo.io/introduction/authentication
- Resend docs : https://resend.com/docs
- Postmark docs : https://postmarkapp.com/developer
- Sentry Next.js : https://docs.sentry.io/platforms/javascript/guides/nextjs/
- PostHog : https://posthog.com/docs

## Mobile futur

- Expo create project : https://docs.expo.dev/get-started/create-a-project/
- React Native environment : https://reactnative.dev/docs/set-up-your-environment
- Expo SecureStore : https://docs.expo.dev/versions/latest/sdk/securestore/

## Sécurité et accessibilité

- OWASP ASVS : https://owasp.org/www-project-application-security-verification-standard/
- OWASP ASVS source/version : https://github.com/OWASP/ASVS
- OWASP Top 10 : https://owasp.org/www-project-top-ten/
- OWASP MASVS : https://mas.owasp.org/MASVS/
- WCAG 2.2 : https://www.w3.org/TR/WCAG22/
- MDN Content Security Policy : https://developer.mozilla.org/docs/Web/HTTP/CSP

## Déploiement (à décider selon résidence/coût)

- Vercel : https://vercel.com/docs
- Cloudflare : https://developers.cloudflare.com/
- GitHub Actions : https://docs.github.com/actions

## Guides de mise en route (exemples)

```bash
npx create-next-app@latest charityy --typescript --tailwind --eslint --app
cd charityy
npm run dev
```

Installer les bibliothèques par besoin et vérifier compatibilité/version avant adoption. Exemple de paquet animation : `npm install motion`; 3D uniquement si décidée : `npm install three @react-three/fiber @react-three/drei`. Ne pas installer toute la liste d’emblée.

Expo natif dans une phase séparée :

```bash
npx create-expo-app@latest charityy-mobile
```

Les commandes créent un squelette; elles ne configurent pas la sécurité, les paiements ou la conformité. Antigravity : consulter sa documentation officielle et les options de sécurité disponibles dans la version installée; ne pas supposer qu’un nom de permission ou mode demeure identique.
