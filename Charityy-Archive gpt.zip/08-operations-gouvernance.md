# 08 — Opérations, administration et gouvernance

## 1. Administration par permissions

Créer des rôles composables, chacun avec permissions précises et périmètre. Éviter un compte « super-admin » utilisé au quotidien.

| Rôle | Responsabilités |
|---|---|
| Vérification | examiner identité, campagne et preuves; demander compléments; pas de paiement |
| Modération | examiner contenus et signalements; appliquer mesures; appel séparé si possible |
| Support | répondre aux demandes; accès aux pièces uniquement au cas nécessaire et journalisé |
| Finance | rapprochement, remboursements et règlements selon double validation; pas d’approbation de campagne |
| Conformité | politiques, escalades, demandes d’autorités, conservation légale |
| Admin utilisateurs | invitations, rôles limités, désactivation; MFA et journal obligatoires |
| Sécurité | incidents, clés, journaux, accès d’urgence audité |
| Auditeur | lecture seule des journaux et rapports minimisés |

Toutes les permissions sont accordées par un admin habilité, expirent ou sont réévaluées périodiquement, et sont révoquées à la fin de mission. MFA, appareil fiable et journalisation sont requis pour comptes équipe. Actions à fort impact utilisent double contrôle.

## 2. Processus d’équipe

- File de vérification avec priorité, propriétaire, échéance, motif et historique.
- File de modération avec gravité et SLA, escalade pour menace, enfant, fuite de données et fraude financière.
- Support avec gabarits validés, minimisation des données et transfert contrôlé.
- Finance avec rapprochement quotidien au lancement, séparation préparation/approbation et rapport d’écart.
- Réunions régulières sur erreurs de vérification, appels, biais géographiques/langues et indicateurs.

## 3. Indicateurs

Suivre conversion des campagnes, temps de vérification, appels admis, fraudes confirmées, plaintes, retraits échoués, événements paiement non rapprochés, temps de résolution, disponibilité et accessibilité. Éviter d’optimiser uniquement le volume de dons ou viralité. Agréger les métriques et éviter de suivre les personnes de façon intrusive.

## 4. Documentation opératoire à écrire avant bêta

Guide de vérification; guide de modération; gestion des demandes de droits; traitement des réclamations et remboursements; incident de données; fraude; suspension et appel; reprise après panne; changement de bénéficiaire; accès d’urgence; départ d’un membre de l’équipe.

## 5. Gouvernance des changements

Toute évolution de taux, règles de collecte, badge, partage de données, pays ou fournisseur nécessite note d’impact, approbation propriétaire de domaine, mise à jour UI/CGU et date d’effet. Journal des décisions dans le document 10.
