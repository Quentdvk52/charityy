# 04 — Paiements, portefeuille et règles financières

## 1. Ce qui est décidé

Moneroo est l’agrégateur visé. Les fonds collectés appartiennent au bénéficiaire selon l’intention produit. Charityy ne doit pas affirmer gérer directement les fonds ou garantir leur règlement tant que le schéma contractuel et technique n’est pas établi. Le projet prévoit un portefeuille de compte, des cadeaux et éventuellement des paiements directs; ces éléments créent des obligations réglementaires et comptables à clarifier.

## 2. Questions obligatoires avec Moneroo

Obtenir une réponse écrite et vérifier dans le contrat/API : pays, devises et moyens réellement actifs; collecte au nom de qui; compte marchand; règlement direct ou comptes bénéficiaires; sous-comptes/split payouts; KYC marchand et bénéficiaire; devises de règlement; délais et frais; remboursements/chargebacks; réserves; limites; webhooks et signature; idempotence; sandbox; rapprochement; traitement des plaintes; disponibilité et support; obligations de conservation et conformité.

L’affirmation « Moneroo intègre tous les moyens de paiement » ne vaut pas couverture universelle. Afficher seulement les méthodes réellement disponibles dans le pays/devise à l’instant du paiement.

## 3. Architecture financière

- Stocker montants en unités mineures entières + code devise.
- Séparer DonationIntent, transaction fournisseur, encaissement confirmé, frais, part bénéficiaire, revenu Charityy, revenu créateur, remboursement et règlement.
- Ledger append-only à double entrée, avec référence externe, idempotence et piste de correction par écritures inverses, jamais réécriture silencieuse.
- Reconciliation périodique et rapports de différences; revue humaine des anomalies.
- Ne jamais afficher une somme « collectée » comme disponible ou réglée sans confirmation de la définition et du flux de fonds.

## 4. Portefeuille

Un portefeuille pouvant être chargé et dépensé peut constituer une valeur stockée, un compte de paiement ou un service réglementé selon le territoire. MVP recommandé : ne pas offrir de solde préchargé, transférable ou retirable. Lancer d’abord un paiement direct par transaction avec fournisseur, sous réserve de légalité et de flux confirmé. Les unités virtuelles de cadeaux ne sont activées qu’après avis spécialisé, règles de remboursement, expiration, protection contre fraude et affichage clair de conversion.

## 5. Frais et modèle économique à valider

Les hypothèses source indiquent : 5 % pour la certification et 2 % de rémunération créateur sur diverses recettes; une version précédente cite 3 % Charityy et frais de paiement. Ces taux ne sont pas assez définis pour coder. Établir avant lancement : assiette (brut/net), qui paie, ordre de calcul, taxe, arrondis, remboursement/chargeback, plafonds, moment de prélèvement, frais fournisseur, exemples chiffrés, consentement et affichage.

La certification ne devrait pas être une condition de protection ou d’accès à une urgence. Un pourcentage du montant collecté peut créer conflit d’intérêt et risque réglementaire; examiner juridiquement et commercialement. Ne pas facturer 5 % en parallèle d’une commission non explicitée.

## 6. Retraits et remboursements

Définir qui initie et autorise; KYC requis; seuils; délai de sécurité; contrôles de changement de bénéficiaire; double approbation; rapprochement; états; paiements échoués; fonds contestés; cas campagne suspendue/objectif non atteint/décès; retour au donateur si possible; preuve de remboursement. Les modalités doivent correspondre aux capacités réelles de Moneroo et au droit local.

## 7. Contrôles anti-fraude

Limites de vitesse et de montant; signaux de risque expliquables; détection de doublons; contrôle des changements de destination; vérification renforcée selon risque; revue humaine et voie d’appel; pas de blocage automatisé définitif basé uniquement sur un score. Respecter les exigences AML/KYC applicables sans présenter Charityy comme institution financière avant validation.
